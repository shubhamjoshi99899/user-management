import React from 'react'

const DynamicForm = () => {
  return (
    <div>DynamicForm</div>
  )
}

export default DynamicForm
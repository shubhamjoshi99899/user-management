import React, { useEffect, useState } from "react";
import { Stepper, Step, StepLabel, Container } from "@mui/material";
import FormComponent from "./Form";
import axios from "axios";
import { useStateContext } from "../StateContext";
import { useNavigate, useParams } from "react-router-dom";

interface Detail {
  name: string;
  label: string;
  type: string;
  required: boolean;
}

interface DetailsObject {
  [key: string]: Detail[];
}

interface MappedObject {
  [key: string]: {
    [key: string]: any;
  };
}

const StepperForm: React.FC = () => {
  const { state } = useStateContext();
  const params = useParams();
  const [activeStep, setActiveStep] = useState(0);
  const [formData, setFormData] = useState<{ [key: string]: string }>({});
  const [dataToCheck, setDataToCheck] = useState<any>({});
  const { dispatch } = useStateContext();
  const navigate = useNavigate();
  const handleNext = () => {
    setActiveStep((prevStep) => prevStep + 1);
  };

  const handleReset = () => {
    setActiveStep(0);
    setFormData({});
    navigate("/");
  };

  const handleBack = () => {
    setActiveStep((prevStep) => prevStep - 1);
  };

  const updateFormData = (data: any) => {
    let newData = {
      ...formData,
      ...data,
    };
    const token = localStorage.getItem("auth_token");
    setFormData(newData);
    axios
      .put(`http::/localhost:3000/update-request/${params?.formId}`, formData, {
        headers: {
          "Content-Type": "application/json",
          Authorization: `Bearer +${token}`,
        },
      })
      .then((data) => {
        console.log("PUT request successful", data);
        // Update state or perform any other actions based on response
      })
      .catch((error) => {
        console.error("Error making PUT request", error);
        // Handle error, if needed
      });
  };

  const getStepsContent = (step: number) => {
    const responseData = state?.responseData;
    // Get the keys of the response data
    const responseKeys = Object.keys(responseData);
    // Check if the step is within the range of available keys
    if (step >= 0 && step < responseKeys?.length) {
      const currentKey = responseKeys[step];
      return responseData[currentKey];
    }

    return null;
  };

  const fetchFormData = () => {
    const token = localStorage.getItem("auth_token");
    axios
      .get(`http://localhost:3000/api/fetch-request/${params.formId}`, {
        headers: {
          Authorization: `Bearer ${token}`,
        },
      })
      .then((res) => {
        dispatch({ type: "SET_DRAFT_DATA", payload: res.data });
      });
  };

  useEffect(() => {
    if (params?.formId?.length) {
      fetchFormData();
    }
  }, [params?.formId]);

  function mapKeysBasedOnStructure(obj2: DetailsObject) {
    return function (obj1: { [key: string]: any }): MappedObject {
      const newObj: MappedObject = {};

      Object.keys(obj2).forEach((property) => {
        newObj[property] = {};

        obj2[property].forEach((detail) => {
          if (obj1.hasOwnProperty(detail.name)) {
            newObj[property][detail.name] = obj1[detail.name];
          }
        });
      });

      return newObj;
    };
  }

  useEffect(() => {
    const mapKeysToObject = mapKeysBasedOnStructure(state?.responseData);
    const mappedObj = mapKeysToObject(formData);
    setDataToCheck(mappedObj);
    console.log(mappedObj);
  }, [state?.responseData, formData]);

  function compareObjects(obj1: any, obj2: any) {
    const missingKeys = [];

    // Iterate through each key in obj2
    for (const category in obj2) {
      const categoryDetails = obj2[category];

      // Iterate through each key-value pair in the category
      for (const key in categoryDetails) {
        if (categoryDetails[key] === "Required") {
          // Check if the key exists in the first object and if its value is truthy
          if (!obj1[category] || !obj1[category][key]) {
            missingKeys.push(key);
          }
        }
      }
    }

    return missingKeys;
  }

  const handleSubmit = () => {
    console.log(
      compareObjects(dataToCheck, state?.requestData?.configurations)
    );
  };

  const saveDraft = (data: any) => {
    let newData = {
      ...data,
    };
    let dataToAppend: any = {
      data: newData,
      type: "creation",
    };
    const token = localStorage.getItem("auth_token");
    axios
      .post("http://localhost:3000/api/create-request", dataToAppend, {
        headers: {
          Authorization: `Bearer ${token}`,
        },
      })
      .then((response: any) => {
        alert("Draft saved successfully");
      })
      .catch((error: any) => {});
  };

  const renderStepContent = (step: number) => {
    return (
      <div>
        <FormComponent
          activeStep={activeStep}
          handleBack={handleBack}
          handleNext={handleNext}
          steps={state?.responseData?.steps}
          formConfig={getStepsContent(activeStep)}
          updateFormData={updateFormData}
          handleSaveDraft={saveDraft}
          handleReset={handleReset}
          handleSubmit={handleSubmit}
        />
      </div>
    );
  };

  return (
    <Container sx={{ mt: 5 }}>
      <Stepper activeStep={activeStep} alternativeLabel>
        {state?.responseData?.steps?.map((label: string) => (
          <Step key={label}>
            <StepLabel>{label}</StepLabel>
          </Step>
        ))}
      </Stepper>
      <div>{renderStepContent(activeStep)}</div>
    </Container>
  );
};

export default StepperForm;

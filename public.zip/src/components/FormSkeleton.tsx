import React from "react";

const FormSkeleton = () => {
  return <div>FormSkeleton</div>;
};

export default FormSkeleton;
